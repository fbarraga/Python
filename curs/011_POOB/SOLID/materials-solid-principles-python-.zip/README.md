# SOLID Principles: Improve Object-Oriented Design in Python

This folder provides the code examples for the Real Python tutorial [SOLID Principles: Improve Object-Oriented Design in Python](https://realpython.com/solid-principles-python/).
